---
layout: post
category: Information
---
Sourdough bread is made by the fermentation of dough using naturally-occurring lactobacilli and yeast. Sourdough bread has a mildly sour taste not present in most breads made with baker's yeast and better inherent keeping qualities than other breads, due to the lactic acid produced by the lactobacilli.

Source / Read more [Wikipedia](https://en.wikipedia.org/wiki/Sourdough)
